<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'chesstudy');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'IV!@!;G$SH8Io81<`@bf-jC$%bUf;ni,?06GNNvVwrq`%@}[AVTFG*qX#5I*hY*V');
define('SECURE_AUTH_KEY',  '~Na4XY~jL ,W[,.O[pFDeo4<&T&[eb-Y%Vk/?v~+._q:i1j:8j~FgzciWk/I7_e3');
define('LOGGED_IN_KEY',    '~1d~*5mGAvD=p]4vE.MK_>tA*57|eAOH.gvkjpz,YOKCt)mDKb@p1yG:u0$lsJ8U');
define('NONCE_KEY',        '+A/9oqo[0tH`QdPt-+xDomxq@`?(,T-)PrmkR<9CgQ^k+Fv jqR`u](H$].g?^y0');
define('AUTH_SALT',        'Pjb*^2`iHC;0s1(dV=;}DYiA+qy_UL_gm;{ F7J32@Om&Z`09ssY*#z5C6VC-jl%');
define('SECURE_AUTH_SALT', 'q+*mu)>:B_h-g`M&#]qMXfSz`|10u@= nF*0i<}ym%9w[xCG}EB1Uu1y5IKRU/)+');
define('LOGGED_IN_SALT',   '~r?M/X8@jegmnY(uzP6|&3SvSH!9>iJs>1TL6+4aw(-7;+Q8:Zw_9T.j/w*RI5(=');
define('NONCE_SALT',       '*j@/eY>L$Fe`|&5c2*l/%_#=WXX4GkKNr uYN}^8MP&r ^h9c5ESBKQ+pvR@Nt.?');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
